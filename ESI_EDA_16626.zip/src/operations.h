#ifndef OPERATIONS_H
#define OPERATIONS_H

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>

typedef enum { FALSE, TRUE } bool;

// Struct e Variaveis globais
typedef struct machine {
    int nOperation;
    int nMachine;
    int vTime;
    struct machine *proximo;
} ListMachines;

typedef struct averageOp {
    int nOperation;
    float vTime;
    struct averageOp *proximo;
} ListAverageOp;

extern ListMachines *listMachines;
extern int nOperationInput;
extern int nMachineInput;
extern int vTimeInput;

//Functions Prototypes
ListMachines *insertAtBeginAndFile(int nOperation, int nMachine, int vTime, ListMachines *list);
ListMachines *insertAtBegin(int nOperation, int nMachine, int vTime, ListMachines *list);
void printListMachines(ListMachines *list);
void printMenu();
bool verifyInputValues(int input);
void newMachineInputs();
bool verifyIfOperationExist(int operationNumber);
bool verifyIfMachineExistInOperation(int operationNumber, int machineNumber);
void removeOperation(int nOperation);
void editOperation(int nOperation);
void printOperationMachines(ListMachines *list, int nOperation);
void minimumAmountOfTime();
void insertAtEnd(int nOperation, int nMachine, int vTime, ListMachines *newList);
int sumMachineTime(ListMachines *list);
void freeList(ListMachines *list);
void freeListAv(ListAverageOp *list);
void maximumAmountOfTime();
void averageOperationTime();
ListAverageOp *insertAtBeginOp(int nOperation, float vTime, ListAverageOp *list);
void saveJob(int nOperation, int nMachine, int vTime);
bool verifyIfFileExist(char *fileName);
void readJob();
void saveJobFromList(ListMachines *list);

#endif